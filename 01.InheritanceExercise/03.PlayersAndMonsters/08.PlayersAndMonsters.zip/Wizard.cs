﻿namespace PlayersAndMonsters;

public class Wizard : Hero
{
    public Wizard(string username, int level) : base(username, level)
    {
    }
}