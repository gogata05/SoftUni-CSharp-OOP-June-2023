﻿namespace ShoppingSpree;

public static class ExceptionMessages
{
    public const string NameExceptionMessage = "Name cannot be empty";
    public const string MoneyExeptionMessage = "Money cannot be negative";
}
