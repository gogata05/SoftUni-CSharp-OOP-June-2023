﻿namespace Telephony.IO.Interfaces;

public interface IWriter
{
    void WriteLine(string line);
}
