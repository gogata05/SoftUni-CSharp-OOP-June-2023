﻿namespace MilitaryElite.Core.Interfaces;

public interface IEngine
{
    void Run();

}
