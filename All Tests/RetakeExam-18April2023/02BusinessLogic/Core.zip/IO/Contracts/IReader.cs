﻿namespace EDriveRent.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
